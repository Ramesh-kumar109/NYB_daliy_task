/*let num=8;
let i
let flag=true;
if(num<=1){
    flag=false
}
else{
for(i=2;i<num;i++){
    if(i%num===0)
    {
        flag=false;
        break;
    }
}
    if(flag==true){
        console.log(num +' is prime number');
    }
    else{
        console.log(num+'is not prime number');
    }

}
*/
/*
let n=15;
let flag=true;
let i
if(n<=1){
    flag=false
}
else{
    for(i=2;i<n;i++){
        if(n%i===0){
            flag=false;
            break;
        }
    }
}
if(flag===true){
   console.log(n+' is prime numer');
}
else{
       console.log(n+' is not prime numer');

}
/*
// prefect number //
 let number=prompt("enter the number");
 let sum=0;
 let o
 for(o=1;o<number;o++){
    if(number%o===0){
          sum+=o;
    }
    
 }
 if(sum==number & number>1){
    console.log(number+"is a prefect number");
 }
 else{
    console.log(number+"is a not prefect number");
 }

*/
// odd number //
/*
let i;
let n=7;
    if(n%2===0){
        console.log(n+'is even number');
    }
    else{
 console.log(n+"is odd number");}
*/

// while loop using even number//
let i=1;
let count=0;
while(count<=10){
    if(i%2===0){
       console.log(i);
       //count++;
}  
       i+=1; 
       count++
  }  
