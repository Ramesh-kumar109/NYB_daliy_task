import React from 'react'

function AboutPage() {
  return (
    <div>
        <h1>about page</h1>
        <p>This appication uses usereducer</p>
    </div>
  )
}

export default AboutPage