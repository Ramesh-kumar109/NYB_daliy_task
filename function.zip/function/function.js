function calling(name){
    console.log(`Hello,${name}`);

}
calling("Ramesh");
//-------function with multiples parameters----//

function add(a,b){
console.log(a+b);
}
add(10,20);
//-------function with default parameters----//
function name(fname="kumar"){
      console.log(" Hello "+fname);
}

let r="ramesh"
name(r);
//----------------------------------------
//---function Experssion------
///1.anonymous function( using without name assign to variable)

const fname=function(lname){
    return` Hi Hello,${lname}`;

}
console.log(fname("Ramesh"))